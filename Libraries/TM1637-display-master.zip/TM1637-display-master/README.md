# TM1637-display
a modified library for TM1637 for display more symbols: degree, 'r' 'h' &amp; 'n' letters and 'u' with _, 'u' with - (2016)
2022: added 'o' letter 

usefull info: http://nicuflorica.blogspot.ro/search?q=TM1637

![schema](https://2.bp.blogspot.com/-DGRHtvxWaeg/Vwyw4nVWLrI/AAAAAAAAPcw/wcVS9iZG4UcAjwbZX0p35OJJcEt26St6ACLcB/s1600/arduino_TM1637_DHT11_schematic.png)
![termometru](https://3.bp.blogspot.com/-7qp1ICEvcmo/Vwyq1b2EvwI/AAAAAAAAPcM/ZM14-FvnRvMrMsHy0dY5bhilWhj6RevUACLcB/s1600/aPB250251.JPG)
![umiditate](https://4.bp.blogspot.com/-tWvDa7BGfbk/Vwys7gLmnwI/AAAAAAAAPck/MAEaFVpCX3w_6R5elj5aVYIC0BhWiWmOA/s1600/bPB250251.JPG)
